//
//  iPhone_TetsAppDelegate.h
//  iPhone Tets
//
//  Created by Developer on 8/6/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@class iPhone_TetsViewController;

@interface iPhone_TetsAppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UIWindow *window;
	IBOutlet iPhone_TetsViewController *viewController;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) iPhone_TetsViewController *viewController;

@end

