//
//  iPhone_TetsViewController.h
//  iPhone Tets
//
//  Created by Developer on 8/6/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iPhone_TetsViewController : UIViewController {

}

@end

