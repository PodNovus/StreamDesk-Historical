//
//  test.m
//  test
//
//  Created by Developer on 8/5/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "test.h"


@implementation test

- (IBAction)doTest:(id)sender
{
	timer = [NSTimer scheduledTimerWithTimeInterval:0 target:self selector:@selector(condition:) userInfo:nil repeats:YES];
}

-(IBAction)changeChkBox:(id)sender
{
	if ([oneObject isOn] == YES){
		[Objs setText:@"1"];
	}else{
		[Objs setText:@"1200"];
	}
}
			 
-(void)condition:(NSTimer*)theTimer
{
	BOOL i = NO;
	
	if (n != -1){
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
		
		if ([dontBlock isOn] == NO){
		i = YES;
		}
	}

if ([oneObject isOn] == NO)
{
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
	
	if(i == NO)
	{
		n++;
		[text setText:[[NSNumber numberWithInt:n] stringValue]];
	}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
			
			//i = YES;
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
			
			//i = YES;
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
			
			//i = YES;
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
			
			//i = YES;
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
		
		if(i == NO)
		{
			n++;
			[text setText:[[NSNumber numberWithInt:n] stringValue]];
		}
	}
	}
}
@end
