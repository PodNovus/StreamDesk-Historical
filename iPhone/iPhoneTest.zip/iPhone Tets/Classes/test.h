//
//  test.h
//  test
//
//  Created by Developer on 8/5/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface test : UIView {

	NSTimer * timer;
	
	IBOutlet UITextField * text;
	IBOutlet UITextField * Objs;
	
	int n;
	
	IBOutlet UISwitch * oneObject;
	IBOutlet UISwitch * dontBlock;
}

- (IBAction)doTest:(id)sender;
- (void)condition:(NSTimer*)theTimer;
-(IBAction)changeChkBox:(id)sender;
@end
