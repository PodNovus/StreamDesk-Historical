//
//  GWAudioPlayback.m
//  GWAudioPlayer
//
//  Created by Developer on 11/30/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "GWAudioPlayback.h"

void GWAudioPlaybackGetBufferSize (
								   AudioStreamBasicDescription ASBDesc,
								   UInt32                      maxPacketSize,
								   Float64                     seconds,
								   UInt32                      *outBufferSize,
								   UInt32                      *outNumPacketsToRead
) {
    static const int maxBufferSize = 512 * 1024;
    static const int minBufferSize = 16 * 1024;
	
    if (ASBDesc.mFramesPerPacket != 0) {
        Float64 numPacketsForTime =
		ASBDesc.mSampleRate / ASBDesc.mFramesPerPacket * seconds;
        *outBufferSize = numPacketsForTime * maxPacketSize;
    } else {
        *outBufferSize =
		maxBufferSize > maxPacketSize ?
		maxBufferSize : maxPacketSize;
    }
	
    if (
        *outBufferSize > maxBufferSize &&
        *outBufferSize > maxPacketSize
		)
        *outBufferSize = maxBufferSize;
    else {
        if (*outBufferSize < minBufferSize)
            *outBufferSize = minBufferSize;
    }
	
    *outNumPacketsToRead = *outBufferSize / maxPacketSize;
}

void audioQueueCallback(void *inClientData, AudioQueueRef inAQ, AudioQueueBufferRef inBuffer){
	GWAudioPlayback * audio = (GWAudioPlayback*)inClientData;
	[audio readFile:inBuffer];
	[audio setBufferUsable:inBuffer];
	[audio setPosition];
	[audio getMeterData];
}

@implementation GWAudioPlayback

@synthesize meters;

- (void)setBufferUsable:(AudioQueueBufferRef)buffer{
	for(UInt32 i = 0; i < kNumberBuffers; i++){
		if (buffer == mBuffers[i]){
			inuse[i] = false;
			break;
		}
	}
}

- (void)getMeterData
{
	UInt32		isRunning;
	UInt32		propertySize = sizeof (UInt32);
	OSStatus	result;
	
	result =	AudioQueueGetProperty (
									   mQueue,
									   kAudioQueueProperty_IsRunning,
									   &isRunning,
									   &propertySize
									   );
	
	if(isRunning != 0){
		AudioQueueGetProperty(mQueue,(AudioQueuePropertyID) kAudioQueueProperty_CurrentLevelMeter, self.meters, &meterSize);
	}
}

- (void)readFile:(AudioQueueBufferRef)buffer
{
	if (mIsRunning == 0) return;
    UInt32 numBytesReadFromFile;
    UInt32 numPackets = mNumPacketsToRead;
    AudioFileReadPackets (mAudioFile,
						  false,
						  &numBytesReadFromFile,
						  mPacketDescs, 
						  mCurrentPacket,
						  &numPackets,
						  buffer->mAudioData 
						  );
    if (numPackets > 0) {
        buffer->mAudioDataByteSize = numBytesReadFromFile;
		AudioQueueEnqueueBuffer ( 
								 mQueue,
								 buffer,
								 (mPacketDescs ? numPackets : 0),
								 mPacketDescs
								 );
		mCurrentPacket += numPackets;
    } else {
        AudioQueueStop (mQueue,false);
        mIsRunning = false; 
    }
}
	
- (void)setFileWithString:(NSString*)filePath
{
	CFURLRef audioFileURL = CFURLCreateFromFileSystemRepresentation (NULL, (const UInt8 *) [filePath fileSystemRepresentation],[filePath length],false);
	OSStatus err;
	
	mCurrentPacket = 0;
	
	err = AudioFileOpenURL(audioFileURL, fsRdPerm, 0, &mAudioFile);
	if(err == noErr){
		UInt32 dataFormatSize = sizeof (mDataFormat);
		AudioFileGetProperty(mAudioFile, kAudioFilePropertyDataFormat, &dataFormatSize, &mDataFormat);
		
		UInt32 bitRateSize = sizeof (mBitRate);
		AudioFileGetProperty(mAudioFile, kAudioFilePropertyBitRate, &bitRateSize, &mBitRate);
		
		UInt32 packetSize = sizeof (mMaxPacketSize);
		AudioFileGetProperty(mAudioFile, kAudioFilePropertyMaximumPacketSize,&packetSize, &mMaxPacketSize);
	}else{
		NSLog(@"Could not create an audio file reference.");
	}
}



-(void)setPosition
{
	AudioTimeStamp timeStamp;
	AudioQueueGetCurrentTime(mQueue, mTimeline, &timeStamp, NULL);
	
	mPosition = timeStamp.mSMPTETime.mSeconds;
}
			
- (void)play
{
	UInt32 cookieSize = sizeof (UInt32);
	BOOL couldNotGetProperty;
	BOOL isFormatVBR;
	
	if(mAudioFile){
		mIsRunning = YES;
	
		AudioQueueNewOutput(&mDataFormat, audioQueueCallback, self, NULL, NULL, 0, &mQueue);
		AudioQueueCreateTimeline(mQueue, &mTimeline);

		meterSize = mDataFormat.mChannelsPerFrame * sizeof(AudioQueueLevelMeterState);
		self.meters = (AudioQueueLevelMeterState *) calloc (sizeof (AudioQueueLevelMeterState), mDataFormat.mChannelsPerFrame);
		
		AudioQueueSetProperty(mQueue, kAudioQueueProperty_EnableLevelMetering, (BOOL*) &meterAudio, 1);
		
		
		GWAudioPlaybackGetBufferSize(mDataFormat, mMaxPacketSize, 0.5, &mBufferByteSize, &mNumPacketsToRead);
	
		isFormatVBR = (mDataFormat.mBytesPerPacket == 0 ||
				   mDataFormat.mFramesPerPacket == 0);
	
		if (isFormatVBR) {
		mPacketDescs =(AudioStreamPacketDescription*) malloc (mNumPacketsToRead * sizeof (AudioStreamPacketDescription));
		}else{
		mPacketDescs = NULL;
		}
	
		couldNotGetProperty = AudioFileGetPropertyInfo (mAudioFile,kAudioFilePropertyMagicCookieData,&cookieSize,NULL);
		if (!couldNotGetProperty && cookieSize) {
			char* magicCookie = (char *) malloc (cookieSize);
		
			AudioFileGetProperty (mAudioFile,kAudioFilePropertyMagicCookieData,&cookieSize,magicCookie);
			AudioQueueSetProperty (mQueue,kAudioQueueProperty_MagicCookie,magicCookie,cookieSize);
			free (magicCookie);
		}
	
		for (int i = 0; i < kNumberBuffers; i++){
			AudioQueueAllocateBuffer(mQueue, mBufferByteSize, &mBuffers[i]);
			audioQueueCallback(self, mQueue, mBuffers[i]);
		}
		AudioQueueStart (mQueue,NULL);
	}
}

-(void)stop
{
	[self setPosition];
	mIsRunning = NO;
	if(mQueue)
		AudioQueueStop(mQueue, true);
}

-(void)dealloc
{
	if(mIsRunning == YES){
		[self stop];
	}
	
	if(mTimeline)
		AudioQueueDisposeTimeline(mQueue, mTimeline);
	if(mQueue)
		AudioQueueDispose(mQueue, true);
	if(mAudioFile)
		AudioFileClose(mAudioFile);
	
	free(mPacketDescs);
	
	[super dealloc];
}
@end
