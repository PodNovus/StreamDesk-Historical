//
//  sAudioPlayer.h
//  GnomeTv iPhone
//
//  Created by Developer on 12/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GWAudio.h"
#import "sPlayButton.h"
#import "sAudioMeter.h"

@interface sAudioPlayer : NSObject {

	GWAudio *					audioStream;
	IBOutlet	sPlayButton *	playButton;
	IBOutlet	id				loadIndicator;
	IBOutlet	sAudioMeter	*	auMeter;
}

- (IBAction)playAudio:(id)sender;
- (void)audioRady:(id)sender;
- (void)getAudioMeter:(GWAudio*)audio;
@end
