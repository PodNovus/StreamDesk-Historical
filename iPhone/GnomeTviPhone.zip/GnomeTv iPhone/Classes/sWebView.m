//
//  sWebView.m
//  GnomeTv iPhone
//
//  Created by Developer on 12/9/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "sWebView.h"


@implementation sWebView

- (void) awakeFromNib
{
	[self loadDefault];
}

- (void)loadDefault
{
	NSURLRequest * aRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://geeks.pirillo.com/"]];
	self.delegate = self;
	[self loadRequest:aRequest];
}

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}

- (void)dealloc {
    [super dealloc];
}

@end

@implementation sWebView(UIWebViewDelegate)
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
	switch (navigationType) {
		case UIWebViewNavigationTypeLinkClicked:
			NSLog(@"link clicked");
			break;
		case UIWebViewNavigationTypeBackForward:
			NSLog(@"back or forward");
			break;
		case UIWebViewNavigationTypeFormResubmitted:
			NSLog(@"Form resubmitted");
			break;
		case UIWebViewNavigationTypeFormSubmitted:
			NSLog(@"form submitted");
			break;
		case UIWebViewNavigationTypeReload:
			NSLog(@"reload");
			break;
		case UIWebViewNavigationTypeOther:
			NSLog(@"Something else happened.");
			break;
	}
	
	NSLog([[request URL] absoluteString]);
	
	return YES;
}
@end
