//
//  GWAudio.m
//  GWAudioPlayer
//
//  Created by Developer on 11/25/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "GWAudioStream.h"


void  propertyProc (void                         *inClientData,
					AudioFileStreamID            inAudioFileStream,
					AudioFileStreamPropertyID    inPropertyID,
					UInt32                       *ioFlags)
{
	GWAudioStream * audio = (GWAudioStream*)inClientData;
	[audio propertyChanged:inPropertyID flags:ioFlags];
}

void packetsProc (void                          *inClientData,
				UInt32                        inNumberBytes,
				UInt32                        inNumberPackets,
				const void                    *inInputData,
				AudioStreamPacketDescription  *inPacketDescriptions)
{
	GWAudioStream * audio = (GWAudioStream*)inClientData;
	[audio packetData:inInputData numberOfPackets:inNumberPackets numberOfBytes:inNumberBytes packetDescriptions:inPacketDescriptions];
}

void audioQueueStreamCallback(void *inClientData, AudioQueueRef inAQ, AudioQueueBufferRef inBuffer){
	GWAudioStream * audio = (GWAudioStream*)inClientData;
	[audio setBufferUsable:inBuffer];
}

/****************************
 GWAudioStream Implementation
 ***************************/
@implementation GWAudioStream

@synthesize meterAudio;
@synthesize meters;
@synthesize  currentLevel;
@synthesize peak;

- (id)init
{
	self = [super init];
	mBufferSize = 1024 * 128;
	return self;
}

- (void)setBufferUsable:(AudioQueueBufferRef)buffer{
	for(UInt32 i = 0; i < kNumberBuffers; i++){
		if (buffer == mBuffers[i]){
			inuse[i] = false;
			break;
		}
	}
}

- (void)getMeterData
{
	if(meterAudio == YES && meteringReady == YES && mQueue) {
		AudioQueueGetProperty(mQueue,(AudioQueuePropertyID) kAudioQueueProperty_CurrentLevelMeter, meters, &meterSize);
	
		currentLevel = 0;
		peak = 0;
		
		for(int i = 0; i < mDataFormat.mChannelsPerFrame; i++){
			currentLevel = currentLevel + meters[i].mAveragePower;
			peak = peak + meters[i].mPeakPower;
		}
		
		currentLevel = currentLevel / mDataFormat.mChannelsPerFrame;
		peak = peak / mDataFormat.mChannelsPerFrame;
	}
}

- (void)setURLWithString:(NSString*)filePath
{
	urlString = [filePath retain];
}

- (void)setMeterAudio:(BOOL)value
{
	meterAudio = value;
}

- (void)stream:(NSStream *)theStream handleEvent:(NSStreamEvent)streamEvent
{
	UInt8 buffer[1024];
	unsigned int length = 0;
	if(streamEvent == NSStreamEventHasBytesAvailable){
		length = [(NSInputStream*)theStream read:buffer maxLength:1024];
		
		if(length > 0){
			AudioFileStreamParseBytes(mAudioFile, length, buffer, 0);
		}
	}
}

- (void)propertyChanged:(AudioFileStreamPropertyID)propertyID flags:(UInt32*)flags
{
	UInt32 cookieSize = sizeof (UInt32);
	BOOL couldNotGetProperty;
	OSStatus err;
	
	switch (propertyID)
	{
		case kAudioFileStreamProperty_ReadyToProducePackets:
		{
			UInt32 asbdSize = sizeof(mDataFormat);
			err = AudioFileStreamGetProperty(mAudioFile,  kAudioFileStreamProperty_DataFormat, &asbdSize, &mDataFormat);
			if (err) NSLog(@"get kAudioFileStreamProperty_DataFormat failed");
			
			if(!mQueue){
				err = AudioQueueNewOutput(&mDataFormat, audioQueueStreamCallback, self, NULL, NULL, 0, &mQueue);
				
				couldNotGetProperty = AudioFileStreamGetPropertyInfo (mAudioFile,kAudioFilePropertyMagicCookieData,&cookieSize,NULL);
				if (!couldNotGetProperty && cookieSize) {
					char* magicCookie = (char *) malloc (cookieSize);
					
					AudioFileStreamGetProperty (mAudioFile,kAudioFilePropertyMagicCookieData,&cookieSize,magicCookie);
					AudioQueueSetProperty (mQueue,kAudioQueueProperty_MagicCookie,magicCookie,cookieSize);
					free (magicCookie);
				}
				
				for (int i = 0; i < kNumberBuffers; i++){
					AudioQueueAllocateBuffer(mQueue, mBufferSize, &mBuffers[i]);
					audioQueueStreamCallback(self, mQueue, mBuffers[i]);
				}
				
				if (err) NSLog(@"AudioQueueNewOutput failed");
				
				
				AudioQueueSetParameter(mQueue, kAudioQueueParam_Volume, gain);
				meterSize = mDataFormat.mChannelsPerFrame * sizeof(AudioQueueLevelMeterState);
				self.meters = (AudioQueueLevelMeterState *) calloc (sizeof (AudioQueueLevelMeterState), mDataFormat.mChannelsPerFrame);
				meteringReady = YES;
				if(meterAudio == YES){
					UInt32 trueValue = true;
					AudioQueueSetProperty(mQueue, kAudioQueueProperty_EnableLevelMetering, (BOOL*) &trueValue, sizeof(UInt32));
				}
				
				if(!_started){
					_started = YES;
					hasJustBegun = YES;
					AudioQueueStart(mQueue, 0);
				}
			}
		}
	}
}

- (void)packetData:(const void*)data numberOfPackets:(UInt32)inNumberPackets numberOfBytes:(UInt32)inNumberBytes packetDescriptions:(AudioStreamPacketDescription*)inPacketDescriptions
{
	SInt64	packetOffset;
	SInt64	packetSize;
	size_t	bufSpaceLeft;
	AudioQueueBufferRef fillBuffer;
	
	if(mBufferSize == 0)
		mBufferSize = 1024*128;
	
	mNumPacketsToRead = inNumberPackets;
	mNumBytesToRead = inNumberBytes;
	
	for(UInt32 i = 0; i < inNumberPackets; i++){
		packetOffset = inPacketDescriptions[i].mStartOffset;
		packetSize = inPacketDescriptions[i].mDataByteSize;
		
		bufSpaceLeft = mBufferSize - mBytesFilled;
		if(bufSpaceLeft < packetSize)
			[self enqueueBuffer];
		fillBuffer = mBuffers[mCurrentBuffer];
		memcpy((char*)fillBuffer->mAudioData + mBytesFilled, (const char*)data + packetOffset, packetSize);
		
		mPacketDescs[mPacketsFilled] = inPacketDescriptions[i];
		mPacketDescs[mPacketsFilled].mStartOffset = mBytesFilled;
		
		mBytesFilled += packetSize;
		mPacketsFilled += 1;
		
		size_t packetsDescsRemaining = kNumberPacketDiscs - mPacketsFilled;
		if (packetsDescsRemaining == 0) [self enqueueBuffer];
	}
	
	if(hasJustBegun == YES){
		hasJustBegun = NO;
		[[NSNotificationCenter defaultCenter] postNotificationName:@"AudioStreamReadyToPlay" object:self];
	}
}
	
- (void)enqueueBuffer
{
	OSStatus err;
	AudioQueueBufferRef fillBuffer;
	
	inuse[mCurrentBuffer] = true;
	fillBuffer = mBuffers[mCurrentBuffer];
	fillBuffer->mAudioDataByteSize = mBytesFilled;
	err = AudioQueueEnqueueBuffer(mQueue, fillBuffer, mPacketsFilled, mPacketDescs);
	
	if (++mCurrentBuffer >= kNumberBuffers) mCurrentBuffer = 0;
	mBytesFilled = 0;
	mPacketsFilled = 0;
}

- (void)play{
	NSURL * audioFileURL = [[NSURL alloc] initWithString:urlString];
	
	CFHTTPMessageRef httpRequest = CFHTTPMessageCreateRequest(
															  kCFAllocatorDefault,
															  CFSTR("GET"),
															  (CFURLRef)audioFileURL,
															  kCFHTTPVersion1_1
															  );
	if(httpRequest)
		urlStream = (NSInputStream*) CFReadStreamCreateForHTTPRequest(kCFAllocatorDefault, httpRequest);
	
	if(urlStream)
		[urlStream setDelegate:self];
	
	
	if(urlStream){
		[urlStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];			//need to put on run loop to send delegate method
		[urlStream open];
		mIsRunning = YES;
		AudioFileStreamOpen(self, propertyProc, packetsProc, kAudioFileMP3Type, &mAudioFile);
	}else{
		NSLog(@"Could not connect to audio stream to play.");
	}
}

-(void)stop
{
	mIsRunning = NO;
	if(mQueue){
		AudioQueueStop(mQueue, true);
		mQueue = nil;
		_started = NO;
		
		AudioFileStreamClose(mAudioFile);
		mAudioFile = nil;
		
		[urlStream close];
		[urlStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
		[urlStream release];
		urlStream = nil;
		
		mBufferSize = 0;
	}
}

-(void)dealloc
{
	if(mIsRunning == YES){
		[self stop];
	}
	
	//if(mTimeline)
		//AudioQueueDisposeTimeline(mQueue, mTimeline);
	if(mQueue)
		AudioQueueDispose(mQueue, true);
	if(mAudioFile)
		AudioFileStreamClose(mAudioFile);
	if(urlStream)
		[urlStream close];
	
	free(mPacketDescs);
	
	[super dealloc];
}

-(AudioQueueRef)audioQueue
{
	if(mQueue)
		return mQueue;
	
	return nil;
}

- (void)setGain:(float)value
{
	if(mQueue)
		AudioQueueSetParameter(mQueue, kAudioQueueParam_Volume, value);
	gain = value;
}
@end
