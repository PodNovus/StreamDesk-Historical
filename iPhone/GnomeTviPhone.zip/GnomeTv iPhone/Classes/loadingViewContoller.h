//
//  loadingViewContoller.h
//  GnomeTv iPhone
//
//  Created by Developer on 12/11/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface loadingViewContoller : UIViewController {
	IBOutlet	UIImageView	*	loaderImageView;
	
	BOOL						isLoading;
}
@property(readonly) BOOL isLoading;
- (void)startLoadProcess;

@end
