//
//  sAudioMeter.m
//  GnomeTv iPhone
//
//  Created by Developer on 12/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "sAudioMeter.h"


@implementation sAudioMeter

- (void)awakeFromNib
{
	auMeterBorder = [[UIImage imageNamed:@"audioMeterBorder.png"] retain];
	self.backgroundColor = [UIColor clearColor];
	[self setNeedsDisplay];
}

- (void)FadeWithMode:(UInt32)mode
{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.5];
	
	if ( mode == 1) {
		self.alpha = 1.0;
	} else {
		self.alpha = 0.0;
	}
	
	[UIView commitAnimations];
}

- (void)setLevel:(float)lv setPeak:(float)pk volume:(float)vol
{
	level = lv;
	peak = pk;
	volume = vol;
	
	[self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect
{
	CGRect imageLocation;
	CGRect levelRect;
	
	/*if (level <= 0.1) {
		CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 0, 100, 0, 1);
	} else if (level <= 0.2 ) {
		CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 0, 150, 0, 1);
	} else if (level <= 0.3 ) {
		CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 0, 200, 0, 1);
	} else if (level <= 0.4 ) {
		CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 0, 250, 0, 1);
	} else if (level <= 0.5 ) {
		CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 100, 250, 0, 1);
	} else if (level <= 0.6 ) {
		CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 200, 150, 0, 1);
	} else if (level <= 0.7 ) {
		CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 250, 100, 0, 1);
	} else if (level >= 0.7 ) {
		CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 250, 0, 0, 1);
	}*/
	
	CGContextSaveGState(UIGraphicsGetCurrentContext());
	CGContextTranslateCTM(UIGraphicsGetCurrentContext(), 0.0, self.bounds.size.height);
	CGContextScaleCTM(UIGraphicsGetCurrentContext(), 1, -1);
	
	imageLocation = CGRectMake(0, self.bounds.size.height - CGImageGetHeight([auMeterBorder CGImage]), CGImageGetWidth([auMeterBorder CGImage]), CGImageGetHeight([auMeterBorder CGImage]));
	CGContextDrawImage(UIGraphicsGetCurrentContext(),
					   imageLocation,
					   [auMeterBorder CGImage]);
	
	CGContextRestoreGState(UIGraphicsGetCurrentContext());
	//render Levels
	CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 0.8, 0.8, 0.8, 1);
	CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), 0.6, 0.6, 0.6, 1);
	CGContextSetLineWidth(UIGraphicsGetCurrentContext(), 2);
	levelRect = CGRectMake(2, 10, (self.bounds.size.width * level) * volume, 10);
	
	CGContextFillRect(UIGraphicsGetCurrentContext(), levelRect);
	CGContextStrokeRect(UIGraphicsGetCurrentContext(), levelRect);

	//render Peak
	CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 0.6, 0.6, 0.6, 1);
	CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), 0.8, 0.8, 0.8, 1);
	levelRect = CGRectMake((self.bounds.size.width * peak) * volume, 10, 10, 10);
	
	CGContextFillRect(UIGraphicsGetCurrentContext(), levelRect);
	CGContextStrokeRect(UIGraphicsGetCurrentContext(), levelRect);
	
}
@end
