//
//  sAudioMeter.h
//  GnomeTv iPhone
//
//  Created by Developer on 12/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface sAudioMeter : UIView {

	UIImage *		auMeterBorder;
	
	UInt32			numberOfChannels;
	float			level;
	float			peak;
	float			volume;
}

- (void)setLevel:(float)lv setPeak:(float)pk volume:(float)vol;
- (void)FadeWithMode:(UInt32)mode;

@end
