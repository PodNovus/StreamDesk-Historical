//
//  mainViewController.h
//  GnomeTv iPhone
//
//  Created by Developer on 12/9/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "sWebView.h"
#import "loadingViewContoller.h"

@interface mainViewController : UIViewController {

	IBOutlet	UIView *					contentsView;
	IBOutlet	sWebView *					theWebView;
	IBOutlet	loadingViewContoller *		loadController;
	
}

- (void)loadApplicationWithRequest:(NSURLRequest*)theRequest;

@end
