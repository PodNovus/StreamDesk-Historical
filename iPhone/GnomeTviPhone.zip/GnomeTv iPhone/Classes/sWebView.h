//
//  sWebView.h
//  GnomeTv iPhone
//
//  Created by Developer on 12/9/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface sWebView : UIWebView <UIWebViewDelegate> {

	
	
}

- (void)loadDefault;
@end
