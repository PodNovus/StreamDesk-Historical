/*
 *  GWCore.h
 *  GWAudioPlayer
 *
 *  Created by Developer on 11/30/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

#if TARGET_OS_IPHONE
	#import <UIKit/UIKit.h>
#else
	#import <Cocoa/Cocoa.h>
#endif