//
//  sEmailButton.m
//  GnomeTv iPhone
//
//  Created by Developer on 12/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "sEmailButton.h"


@implementation sEmailButton

- (void)awakeFromNib{
	[self setup];
}

- (void)setup
{
	self.buttonImage = [[UIImage imageNamed:@"EmailButton.png"] retain];
	self.buttonDown = [[UIImage imageNamed:@"EmailButtonDown.png"] retain];
	self.ButtonReflection = [[UIImage imageNamed:@"playButtonReflection.png"] retain];
	self.buttonReflectionDown = [[UIImage imageNamed:@"playButtonDownReflection.png"] retain];
	[self setOpaque:NO];
	[self setBackgroundColor:[UIColor clearColor]];
}
@end
