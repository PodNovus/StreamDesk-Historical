//
//  GnomeTv_iPhoneAppDelegate.h
//  GnomeTv iPhone
//
//  Created by Developer on 11/30/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "mainViewController.h"
#import "loadingViewContoller.h"
#import "sWebView.h"

@interface GnomeTv_iPhoneAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	IBOutlet mainViewController * mController;
	IBOutlet loadingViewContoller * loadController;
	IBOutlet UIViewController *		webController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

