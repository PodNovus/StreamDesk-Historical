//
//  GWAudio.h
//  GWAudioPlayer
//
//  Created by Developer on 11/27/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GWAudioPlayback.h"
#import "GWAudioStream.h"
#import <AudioToolbox/AudioQueue.h>


@interface GWAudio : NSObject {

	id				audioFile;
	
	BOOL			isStream;
	NSString *		streamURL;
	BOOL			isPlaying;
	float			volume;
	
	//metering
	NSTimer *		meterTimer;
	BOOL			isMetering;
	id				target;
	SEL				selector;
	
	float			currentLevel;
	float			currentPeak;
}
@property(assign) id target;
@property(assign) SEL selector;
@property (assign) float currentLevel;
@property (assign) float currentPeak;
@property (readonly) float volume;

- (void)setStreamWithString:(NSString*)url;

- (void)play;
- (void)stop;
- (void)setVolume:(float)value;

- (void)setMeterAudio:(BOOL)value;
@end
