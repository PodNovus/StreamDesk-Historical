//
//  GWAudio.m
//  GWAudioPlayer
//
//  Created by Developer on 11/27/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "GWAudio.h"


@implementation GWAudio
@synthesize target;
@synthesize selector;
@synthesize currentLevel;
@synthesize currentPeak;
@synthesize volume;

- (void)setStreamWithString:(NSString*)url
{
	if(audioFile)
		[audioFile release];
	
	audioFile = [[GWAudioStream alloc] init];
	isStream = YES;
	[audioFile setURLWithString:url];
	streamURL = [url retain];
}

- (void)play
{
	if(audioFile){
		[audioFile setGain:volume];
		[(GWAudioStream*)audioFile play];
	}
}

- (void)stop
{
	if(audioFile) {
		[(GWAudioStream*)audioFile stop];
		[audioFile release];
		
		if(isStream) {
			audioFile = [[GWAudioStream alloc] init];
			[audioFile setURLWithString:streamURL];
		}
	}
}

- (void)setVolume:(float)value
{
	if(audioFile)
		[audioFile setGain:value];
	
	volume = value;
}

- (void)setMeterAudio:(BOOL)value
{
	isMetering = value;
	if(audioFile){
		[audioFile setMeterAudio:value];
		meterTimer = [NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(myTimerFireMethod:) userInfo:NULL repeats:YES];
	}
}

- (void)myTimerFireMethod:(NSTimer*)theTimer
{
	[audioFile getMeterData];
	currentLevel = [audioFile currentLevel];
	currentPeak = [audioFile peak];
	
	[target performSelector:selector withObject:self];
}
@end
