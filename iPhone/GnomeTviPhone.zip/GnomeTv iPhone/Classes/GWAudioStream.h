//
//  GWAudio.h
//  GWAudioPlayer
//
//  Created by Developer on 11/25/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "GWCore.h"
#import <AudioToolbox/AudioQueue.h>
#import <AudioToolbox/AudioFileStream.h>

#define kNumberBuffers 3
#define kNumberPacketDiscs 512

@interface GWAudioStream : NSObject {

	NSString *						urlString;
	
	AudioStreamBasicDescription		mDataFormat;
    AudioQueueRef					mQueue;
    AudioQueueBufferRef				mBuffers[kNumberBuffers];
    AudioFileStreamID				mAudioFile;
	NSInputStream *					urlStream;
	UInt32							mMaxPacketSize;
	UInt32							mBitRate;
    UInt32							mNumPacketsToRead;
	UInt32							mNumBytesToRead;
    AudioStreamPacketDescription	mPacketDescs[kNumberPacketDiscs];
    bool							mIsRunning;
	
	bool							inuse[kNumberBuffers];
	
	UInt32							mBufferSize;
	UInt32							mBytesFilled;
	int								mCurrentBuffer;
	UInt32							mPacketsFilled;
	
	AudioQueueTimelineRef			mTimeline;
	float							mPosition;
	
	BOOL							_started;
	BOOL							hasJustBegun;
	
	AudioQueueLevelMeterState *		meters;
	UInt32							meterSize;
	BOOL							meterAudio;
	float							currentLevel;
	float							peak;
	BOOL							meteringReady;
	float							gain;
}
@property(assign) BOOL				meterAudio;
@property(readwrite) AudioQueueLevelMeterState * meters;
@property(assign) float			currentLevel;
@property(assign) float			peak;

- (void)setBufferUsable:(AudioQueueBufferRef)buffer;
- (void)stream:(NSStream *)theStream handleEvent:(NSStreamEvent)streamEvent;
- (void)propertyChanged:(AudioFileStreamPropertyID)propertyID flags:(UInt32*)flags;
- (void)packetData:(const void*)data numberOfPackets:(UInt32)inNumberPackets numberOfBytes:(UInt32)inNumberBytes packetDescriptions:(AudioStreamPacketDescription*)inPacketDescriptions;
- (void)enqueueBuffer;
- (void)setURLWithString:(NSString*)filePath;
- (void)play;
- (void)stop;
- (void)setGain:(float)value;

- (void)getMeterData;
- (void)setMeterAudio:(BOOL)value;

-(AudioQueueRef)audioQueue;
@end
