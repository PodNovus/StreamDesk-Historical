//
//  GnomeTv_iPhoneAppDelegate.m
//  GnomeTv iPhone
//
//  Created by Developer on 11/30/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import "GnomeTv_iPhoneAppDelegate.h"

@implementation GnomeTv_iPhoneAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
	[window addSubview:[mController view]];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
