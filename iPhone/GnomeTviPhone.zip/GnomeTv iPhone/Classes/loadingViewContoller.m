//
//  loadingViewContoller.m
//  GnomeTv iPhone
//
//  Created by Developer on 12/11/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "loadingViewContoller.h"


@implementation loadingViewContoller
@synthesize isLoading;
/*
// Override initWithNibName:bundle: to load the view using a nib file then perform additional customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/


// Implement loadView to create a view hierarchy programmatically.
- (void)loadView {

}

/*
// Implement viewDidLoad to do additional setup after loading the view.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
    [super dealloc];
}

- (void)startLoadProcess
{
	NSArray * imageArray = [[NSArray alloc] initWithObjects:
							[UIImage imageNamed:@"loadingCircle1.png"],
							[UIImage imageNamed:@"loadingCircle2.png"],
							[UIImage imageNamed:@"loadingCircle3.png"],
							[UIImage imageNamed:@"loadingCircle4.png"],
							[UIImage imageNamed:@"loadingCircle5.png"],
							[UIImage imageNamed:@"loadingCircle6.png"],
							[UIImage imageNamed:@"loadingCircle7.png"],
							[UIImage imageNamed:@"loadingCircle8.png"],
							[UIImage imageNamed:@"loadingCircle9.png"],
							[UIImage imageNamed:@"loadingCircle10.png"],
							[UIImage imageNamed:@"loadingCircle11.png"],
							[UIImage imageNamed:@"loadingCircle12.png"],
							[UIImage imageNamed:@"loadingCircle13.png"],
							[UIImage imageNamed:@"loadingCircle14.png"],
							[UIImage imageNamed:@"loadingCircle15.png"],
							[UIImage imageNamed:@"loadingCircle16.png"],
							[UIImage imageNamed:@"loadingCircle17.png"],
							[UIImage imageNamed:@"loadingCircle18.png"],
							[UIImage imageNamed:@"loadingCircle19.png"],
							[UIImage imageNamed:@"loadingCircle20.png"],
							[UIImage imageNamed:@"loadingCircle21.png"],
							[UIImage imageNamed:@"loadingCircle22.png"],
							[UIImage imageNamed:@"loadingCircle23.png"],
							[UIImage imageNamed:@"loadingCircle24.png"],
							[UIImage imageNamed:@"loadingCircle25.png"],
							[UIImage imageNamed:@"loadingCircle26.png"],
							[UIImage imageNamed:@"loadingCircle27.png"],
							[UIImage imageNamed:@"loadingCircle28.png"],
							[UIImage imageNamed:@"loadingCircle29.png"],
							[UIImage imageNamed:@"loadingCircle30.png"],
							nil];
	[loaderImageView setAnimationImages:imageArray];
	[loaderImageView setAnimationDuration:2.0];
	[loaderImageView startAnimating];
	[imageArray release];
}
@end
