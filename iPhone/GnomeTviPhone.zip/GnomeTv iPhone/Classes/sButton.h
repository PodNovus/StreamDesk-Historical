//
//  sButton.h
//  GnomeTv iPhone
//
//  Created by Developer on 12/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface sButton : UIControl {

	UIImage *		buttonImage;
	UIImage *		buttonDown;
	UIImage *		ButtonReflection;
	UIImage *		buttonReflectionDown;
	UInt32			imageWidth;
	UInt32			imageHeight;
	
}
@property(assign)	UIImage *		buttonImage;
@property(assign)	UIImage *		buttonDown;
@property(assign)	UIImage *		ButtonReflection;
@property(assign)	UIImage *		buttonReflectionDown;

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event;

- (void)changeVisual;
@end
