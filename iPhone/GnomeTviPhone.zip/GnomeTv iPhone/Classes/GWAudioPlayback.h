//
//  GWAudioPlayback.h
//  GWAudioPlayer
//
//  Created by Developer on 11/30/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "GWCore.h"
#import <AudioToolbox/AudioQueue.h>
#import <AudioToolbox/AudioFile.h>

#define kNumberBuffers 3

@interface GWAudioPlayback : NSObject {

	AudioStreamBasicDescription		mDataFormat;
    AudioQueueRef					mQueue;
    AudioQueueBufferRef				mBuffers[kNumberBuffers];
    AudioFileID						mAudioFile;
    UInt32							mBufferByteSize;
	UInt32							mMaxPacketSize;
	UInt32							mBitRate;
    SInt64							mCurrentPacket;
    UInt32							mNumPacketsToRead;
    AudioStreamPacketDescription	*mPacketDescs;
    bool							mIsRunning;
	
	bool							inuse[kNumberBuffers];
	
	AudioQueueTimelineRef			mTimeline;
	float							mPosition;
	
	AudioQueueLevelMeterState *		meters;
	UInt32							meterSize;
	BOOL							meterAudio;
	BOOL							meteringReady;
}
@property(readwrite) AudioQueueLevelMeterState * meters;

- (void)setBufferUsable:(AudioQueueBufferRef)buffer;
- (void)readFile:(AudioQueueBufferRef)buffer;

- (void)getMeterData;

- (void)setFileWithString:(NSString*)filePath;
- (void)play;
-(void)stop;
-(void)setPosition;
@end
