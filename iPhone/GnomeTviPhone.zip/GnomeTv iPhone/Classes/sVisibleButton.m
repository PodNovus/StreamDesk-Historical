//
//  sVisibleButton.m
//  GnomeTv iPhone
//
//  Created by Developer on 12/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "sVisibleButton.h"


@implementation sVisibleButton

- (void)awakeFromNib{
	[self setup];
}

- (void)setup
{
	self.buttonImage = [[UIImage imageNamed:@"invisibleButton.png"] retain];
	self.buttonDown = [[UIImage imageNamed:@"invisibleButtonDown.png"] retain];
	self.ButtonReflection = [[UIImage imageNamed:@"playButtonReflection.png"] retain];
	self.buttonReflectionDown = [[UIImage imageNamed:@"playButtonDownReflection.png"] retain];
	[self setOpaque:NO];
	[self setBackgroundColor:[UIColor clearColor]];
}

- (void)changeVisual
{
	if ( self.selected == YES ) {
		
		[self.buttonImage release];
		[self.buttonDown release];
		[self.ButtonReflection release];
		[self.buttonReflectionDown release];
		
		self.buttonImage = [[UIImage imageNamed:@"invisibleButton.png"] retain];
		self.buttonDown = [[UIImage imageNamed:@"invisibleButtonDown.png"] retain];
		self.ButtonReflection = [[UIImage imageNamed:@"pauseButtonReflection.png"] retain];
		self.buttonReflectionDown = [[UIImage imageNamed:@"pauseButtonDownReflection.png"] retain];
	} else {
		[self.buttonImage release];
		[self.buttonDown release];
		[self.ButtonReflection release];
		[self.buttonReflectionDown release];
		
		self.buttonImage = [[UIImage imageNamed:@"invisibleButton.png"] retain];
		self.buttonDown = [[UIImage imageNamed:@"invisibleButtonDown.png"] retain];
		self.ButtonReflection = [[UIImage imageNamed:@"playButtonReflection.png"] retain];
		self.buttonReflectionDown = [[UIImage imageNamed:@"playButtonDownReflection.png"] retain];
	}
}


@end
