//
//  mainView.m
//  GnomeTv iPhone
//
//  Created by Developer on 12/9/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "mainView.h"


@implementation mainView


- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}


- (void)dealloc {
    [super dealloc];
}


@end
