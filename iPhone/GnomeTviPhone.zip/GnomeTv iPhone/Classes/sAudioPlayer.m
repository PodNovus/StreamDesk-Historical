//
//  sAudioPlayer.m
//  GnomeTv iPhone
//
//  Created by Developer on 12/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "sAudioPlayer.h"


@implementation sAudioPlayer

- (void)awakeFromNib
{
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(audioRady:) name:@"AudioStreamReadyToPlay" object:nil];
}

- (IBAction)playAudio:(id)sender
{
	if (!audioStream){
		audioStream = [[GWAudio alloc] init];
		[audioStream setStreamWithString:@"http://phobos.geeksradio.fm:8000"];
		[audioStream setTarget:self];
		[audioStream setSelector:@selector(getAudioMeter:)];
		[audioStream setVolume:0.5];
	}
	
	[audioStream setMeterAudio:YES];
	if ( [sender isSelected] == YES ) {
		[audioStream play];
		[loadIndicator startAnimating];
		[auMeter FadeWithMode:1];
	} else {
		[audioStream stop];
		[auMeter FadeWithMode:0];
	}
}

- (void)audioRady:(id)sender
{
	[loadIndicator stopAnimating];
}

- (void)getAudioMeter:(GWAudio*)audio
{
	[auMeter setLevel:[audio currentLevel] setPeak:[audio currentPeak] volume:[audio volume]];
}
@end
