//
//  sButton.m
//  GnomeTv iPhone
//
//  Created by Developer on 12/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "sButton.h"


@implementation sButton
@synthesize buttonImage;
@synthesize buttonDown;
@synthesize ButtonReflection;
@synthesize buttonReflectionDown;

- (void)drawRect:(CGRect)rect
{
	CGRect imageLocation;
	
	imageWidth = self.bounds.size.width;
	imageHeight = self.bounds.size.height / 2;
	
	CGContextTranslateCTM(UIGraphicsGetCurrentContext(), 0.0, self.bounds.size.height);
	CGContextScaleCTM(UIGraphicsGetCurrentContext(), 1, -1);
	
	if ( self.highlighted == NO ) {
		if ( buttonImage ) {
			
			//render the reflection first so that it is underneath the real image
			imageLocation = CGRectMake(0, 2, imageWidth, imageHeight);
			CGContextDrawImage(UIGraphicsGetCurrentContext(),
							   imageLocation,
							   [ButtonReflection CGImage]);
			
			imageLocation = CGRectMake(0, imageHeight, imageWidth, imageHeight);
			CGContextDrawImage(UIGraphicsGetCurrentContext(),
							   imageLocation,
							   [buttonImage CGImage]);
		}
	}else if ( self.highlighted == YES ) {
		if ( buttonImage ) {
			
			//render the reflection first so that it is underneath the real image
			imageLocation = CGRectMake(0, 2, imageWidth, imageHeight);
			CGContextDrawImage(UIGraphicsGetCurrentContext(),
							   imageLocation,
							   [buttonReflectionDown CGImage]);
			
			imageLocation = CGRectMake(0, imageHeight, imageWidth, imageHeight);
			CGContextDrawImage(UIGraphicsGetCurrentContext(),
							   imageLocation,
							   [buttonDown CGImage]);
		}
	}
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch * touch = [touches anyObject];
	
	if([touch locationInView:self].y <= imageHeight){
		self.highlighted = YES;
		[self setNeedsDisplay];
	}
}

- (void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	
	UITouch * touch = [touches anyObject];
	
	if([touch locationInView:self].y <= imageHeight){
		if([touch locationInView:self].y >= 0){
			if([touch locationInView:self].x <= imageWidth){
				if([touch locationInView:self].x >= 0){
		
					if (self.selected == YES) {
						self.selected = NO;
					} else {
						self.selected = YES;
					}
					[self sendActionsForControlEvents:UIControlEventTouchDown];
				}
			}
		}
	}
	
		self.highlighted = NO;
		[self changeVisual];
		[self setNeedsDisplay];
}

- (void)changeVisual
{
}
@end
